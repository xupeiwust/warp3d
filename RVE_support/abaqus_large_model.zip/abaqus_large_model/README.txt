
README.txt


Abaqus input file (abaqus.inp) and include files
to run a linear-elastic analysis 
for a rectangular prism RVE with periodic boundary
conditions.

The model has 113143 nodes, 23200 20-node hex
elements.

The loading imposes a shear (1,2) strain on the
RVE.

There are 54,389 multi-point constraint equations
to impose the periodic displacement conditions.

The solution requires ~ 25 seconds walltime on a few
threads of older (2020-2025) Intel/AMD processors. 

  abaqus.inp
    includes: abaqus_coords.inp, abaqus_incid.inp, mpcs.inp
    
 rve_mpc_generator.py
    generates *BOUNDARY and *EQUATION  commands
    
 rve_input_eps12.inp
    input to  rve_mpc_generator.py for this model   
      